import image from './path/to/image.jpg';

export default image;